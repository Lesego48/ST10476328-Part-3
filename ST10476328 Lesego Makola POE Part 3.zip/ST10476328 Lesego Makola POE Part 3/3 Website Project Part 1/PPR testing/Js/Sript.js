
const accordions = document.querySelectorAll(".accordion");

accordions.forEach(function(button) {
    button.addEventListener("click", function() {
        const panel = this.nextElementSibling;

        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
});


const map = L.map('map').setView([-23.9045, 29.4689], 13);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

L.marker([-23.9045, 29.4689])
    .addTo(map)
    .bindPopup('Polokwane Paws Rescue')
    .openPopup();

    
document.getElementById("welcomeButton")
.addEventListener("click", function() {

    document.getElementById("welcomeMessage").textContent =
    "Welcome to Polokwane Paws Rescue! Give a loving pet a forever home.";

});


const galleryImages = document.querySelectorAll(".gallery-img");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const closeLightbox = document.getElementById("closeLightbox");

galleryImages.forEach(function(image) {
    image.addEventListener("click", function() {
        lightboxImage.src = image.src;
        lightboxImage.alt = image.alt;
        lightbox.style.display = "flex";
    });
});

closeLightbox.addEventListener("click", function() {
    lightbox.style.display = "none";
});

lightbox.addEventListener("click", function(event) {
    if (event.target === lightbox) {
        lightbox.style.display = "none";
    }
});

// Client-Side Validation with Error Handling + AJAX Simulation
document.getElementById('enquiryForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const msg = document.getElementById('message').value.trim();
  const response = document.getElementById('enquiryResponse');

  if(name.length < 3){ response.textContent = "Name must be at least 3 characters"; response.style.color="red"; return; }
  if(!email.includes('@')){ response.textContent = "Enter valid email"; response.style.color="red"; return; }
  if(msg.length < 10){ response.textContent = "Message must be 10+ characters"; response.style.color="red"; return; }

  // AJAX simulation - DOM manipulation
  response.textContent = "Processing...";
  setTimeout(() => {
    let cost = enquiryType.value === 'adoption' ? 'Adoption fee: R650 (includes vaccines)' : 'Volunteering: Free - 2 hours per week';
    response.innerHTML = `Thank you ${name}! ${cost}. We will email you at ${email} within 24 hours.`;
    response.style.color = "green";
    // Simulate AJAX submission
    fetch('https://httpbin.org/post', {method:'POST', body: JSON.stringify({name,email})})
      .then(res => console.log('Form submitted'));
  }, 1000);
});

// Contact form sends email
document.getElementById('contactForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  const email = document.getElementById('cEmail').value;
  window.location.href = `mailto:info@polokwanepaws.co.za?subject=Contact from ${email}&body=${document.getElementById('cMessage').value}`;
});